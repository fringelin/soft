# external_ui

A Flutter project for testing external texture rendering.
