# Splash Demo: Long transition animation

This project is an example of a splash screen that fades very slowly to the Flutter UI.

A slow transition is provided as a demo so that developers can manually verify that orientation
changes and other UI destruction processes do not cause issues with Flutter's splash system for
Android.
